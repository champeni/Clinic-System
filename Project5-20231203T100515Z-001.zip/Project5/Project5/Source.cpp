//Programmed by Group 9
#include<iostream>
using namespace std;
//Structure array
struct node
{
    char fname[20];
    char lname[20];
    int age;
    char gender[8];
    int id;
    char symptom[500];
    struct node* next;
    
};
//Structure access condition
struct node* head, * lastptr;
bool check = true;
int arr[1000] = { 0 }, i = 0;
bool check_id(int ch)
{
    for (int a = 0; a < i; a++)
    {
        if (ch == arr[a])
        {
            return true;
        }
    }
    return false;
};
//Group student
class student
{
    //Public means can be accessed even outside the group
public:
    //Adding New record of Patient
    void add()
    {

        node* p;
        p = new node;
        // get the user input

        cout << "[----------------------------]" << endl;
        cout << "[------Enter Patient ID------]" << endl;
        cout << "[----------------------------]" << endl;

        cin >> p->id;  

        cout << "[----------------------------]" << endl;
        cout << "|--Enter Patient First name--|" << endl;
        cout << "[----------------------------]" << endl;

        cin >> p->fname;

      
      
        cout << "[----------------------------]" << endl;
        cout << "|---Enter Patient Last name--|" << endl;
        cout << "[----------------------------]" << endl;

        cin >> p->lname;
        

        cout << "[----------------------------]" << endl;
        cout << "|------Enter Patient Age-----|" << endl;
        cout << "[----------------------------]" << endl;

        cin >> p->age;

        cout << "[----------------------------]" << endl;
        cout << "|----Enter Patient Gender----|" << endl;
        cout << "[----------------------------]" << endl;

        cin >> p->gender;

        cout << "[----------------------------]" << endl;
        cout << "|---------Enter symptom------|" << endl;
        cout << "[----------------------------]" << endl;

        cin >> p->symptom;
        

        p->next = NULL;
        arr[i] = p->id;

        i++;
        if (check)
        {
            head = p;
            lastptr = p;
            check = false;
        }
        else
        {
            lastptr->next = p;
            lastptr = p;
        }

    }
    //Showing Patient records
    void show()
    {
        int n;
        node* current = NULL, * prev = NULL;
        prev = head;
        current = head;
        int ch;
        cout << "Enter Patient ID:" << endl;
        cin >> ch;
        if (check_id(ch))
        {
            while (current->id != ch)
            {
                prev = current;
                current = current->next;
            }

            // Print out the user data

            cout << "|-------------------------|" << endl;
            cout << "|----Patient First name---|" << endl;
            cout << "|-------------------------|" << endl;

            cout << current->fname << endl;
           
            

            cout << "|-------------------------|" << endl;
            cout << "|----Patient Last name----|" << endl;
            cout << "|-------------------------|" << endl;

            cout << current->lname << endl;

            cout << "|-------------------------|" << endl;
            cout << "|-------Patient ID--------|" << endl;
            cout << "|-------------------------|" << endl;

            cout << current->id << endl;

            cout << "|-------------------------|" << endl;
            cout << "|-------Patient Age-------|" << endl;
            cout << "|-------------------------|" << endl;

            cout << current->age << endl;

            cout << "|-------------------------|" << endl;
            cout << "|------Patient Gender-----|" << endl;
            cout << "|-------------------------|" << endl;

            cout << current->gender << endl;

            cout << "|-------------------------|" << endl;
            cout << "|---------Symptoms--------|" << endl;
            cout << "|-------------------------|" << endl;

            cout << current->symptom << endl;

            cout << "|-------------------------|" << endl;
            cout << "\n";


        }
    }
    //Deleting Patient Record
    void deleteList()
    {
        int counter = 0;
        node* current = NULL, * prev = NULL;

        //current =new node;

        prev = head;
        current = head;
        int ch;
        cout << "Enter the ID: ";
        cin >> ch;
        if (check_id(ch)) {
            //	temp=head;
            while (current->id != ch)
            {
                prev = current;
                current = current->next;
            }
            prev->next = current->next;
            free(current);

            //  	while(head != NULL)
            //    {
            //        temp = head;
            //        head = head->next;
            //
            //        free(temp);
            //    }
            for (int a = 0; a < i; a++)
            {
                if (arr[a] == ch) {
                    for (int j = a; j < i; j++) {
                        arr[j] = arr[j + 1];
                    }
                    i--;
                }
            }
            cout << " * SUCCESSFULLY DELETED ALL NODES OF LINKED LIST! * \n";
        }
        else
            cout << "ERROR 101: ID NOT FOUND" << endl;
    }
    //Updating of Patient Record Menu
    void update_menu()
    {
        cout << "|--------------------------------|" << endl;
        cout << "| * Enter 1 Patient First name   |" << endl;
        cout << "| * Enter 2 Patient Last name    |" << endl;
        cout << "| * Enter 3 Patient ID           |" << endl;
        cout << "| * Enter 4 Patient Age          |" << endl;
        cout << "| * Enter 5 Patient Gender       |" << endl;
        cout << "| * Enter 6 Symptoms             |" << endl;
        cout << "|--------------------------------|" << endl;
    }
    //Updating of Patient Menu Paths
    void update_data()
    {
        node* current = NULL, * prev = NULL;
        current = head;
        prev = head;
        int id, ch;
        cout << "enter ID" << endl;
        cin >> id;
        if (check_id(id)) {
            while (current->id != id)
            {
                prev = current;
                current = current->next;
            }
            update_menu();
            cout << "chose number" << endl;
            cin >> ch;
            if (ch == 1) {
                cout << "|--------------------------|" << endl;
                cout << "|-----Enter first name-----|" << endl;
                cout << "|--------------------------|" << endl;
                cin >> current->fname;
                cin.getline(current->fname, 20);
                fflush(stdin);
            }
            else if (ch == 2) {
                cout << "|--------------------------|" << endl;
                cout << "|------Enter second name---|" << endl;
                cout << "|--------------------------|" << endl;
                cin >> current->lname;
            }
            else if (ch == 3) {
                cout << "|--------------------------|" << endl;
                cout << "|---------Enter ID---------|" << endl;
                cout << "|--------------------------|" << endl;
                cin >> current->id;
            }
            else if (ch == 4) {
                cout << "|--------------------------|" << endl;
                cout << "|---------Enter age--------|" << endl;
                cout << "|--------------------------|" << endl;
                cin >> current->age;
            }
            else if (ch == 5) {
                cout << "|--------------------------|" << endl;
                cout << "|-------Enter gender-------|" << endl;
                cout << "|--------------------------|" << endl;
                cin >> current->gender;
            }
            else if (ch == 6) {
                cout << "|--------------------------|" << endl;
                cout << "|Enter New Updated Symptoms|" << endl;
                cout << "|--------------------------|" << endl;
                cin >> current->symptom;
            }
        }
        else
            cout << " * ID not present! * " << endl;
    }
    //Exiting the Program
    void exit() {
        node* current = NULL, * prev = NULL;
        current = head;
        prev = head;
        exit();
    }
};

void dis()
{
    // Main Menu
    cout << "|--------------------------------------|" << endl;
    cout << "| University of Batangas Clinic System |" << endl;
    cout << "|--------------------------------------|" << endl;
    cout << "|      1. ADD NEW PATIENT RECORD       |" << endl;
    cout << "|      2. FULL HISTORY OF PATIENT      |" << endl;
    cout << "|      3. DELETE PATIENT RECORD        |" << endl;
    cout << "|      4. UPDATE PATIENT RECORD        |" << endl;
    cout << "|      5. EXIT PROGRAM                 |" << endl;
    cout << "|--------------------------------------|" << endl;
    cout << "|         Enter a number (1-5)         |" << endl;
    cout << "|--------------------------------------|" << endl;
}

//Accessing each functions
int main()
{
    struct node* head = NULL;
    student u;
    int i = 0;
    do {
        dis();
        cin >> i;
        if (i == 1)
            u.add();
        else if (i == 2)
            u.show();
        else if (i == 3)
            u.deleteList();
        else if (i == 4)
            u.update_data();
        else if (i == 5)
            u.exit();
    } while (1);
    return 0;
}